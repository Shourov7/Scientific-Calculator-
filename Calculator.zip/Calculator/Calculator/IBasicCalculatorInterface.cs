﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
   public  interface IBasicCalculatorInterface
    {
         double sum(double x, double y);
         double sub(double x, double y);
         double multiplication(double x, double y) ;
         double division(double x, double y);

    }
}
