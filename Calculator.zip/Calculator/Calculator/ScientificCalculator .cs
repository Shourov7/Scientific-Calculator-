﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class ScientificCalculator : ScientificCalculatorInterface
    {
        public double result = 1, i;


        public double XtoY(double x, double y)
        {
            Console.WriteLine("TO the Power");
            for (i = 0; i < y; i++)
                result = result * x;
            return result;

        }
                
        public double fact( int y)
        {
            Console.WriteLine("Factorial");

            double fact = 1,i;
            for(i=1;i<=y;i++)
            {
                fact *=i;
            
            }

            return fact;
        }
        public void mod(double x, double y)
        {
            double Result, Reminder;

            Result = x / y;
            Reminder = x % y;
            Console.WriteLine("Result" + Result);
            Console.WriteLine("Reminder"+Reminder);
        
        
        }
        public void DecimalToBinary(int x)
        
           {

            string binary = Convert.ToString(x, 2);
            Console.WriteLine(binary);

            }
        
    }
}