﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            BasicCalculator bs = new BasicCalculator();
            Console.WriteLine(bs.sum(5,5));
            Console.WriteLine(bs.sub(5, 5));
            Console.WriteLine(bs.multiplication(5, 5));
            Console.WriteLine(bs.division(5, 5));
            ScientificCalculator sc = new ScientificCalculator();
            Console.WriteLine(sc.XtoY(2,3));
            Console.WriteLine(sc.fact(4));
            sc.mod(5,2);
            sc.DecimalToBinary(4);

        }
    }
}
