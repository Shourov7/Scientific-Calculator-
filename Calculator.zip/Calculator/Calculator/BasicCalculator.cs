﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class BasicCalculator : IBasicCalculatorInterface
    {
        // public double a, b, c, d;
        public double result = 0;

        public double sum(double x, double y)
        {


            return x + y;
        }
        public double sub(double x, double y)
        {

            return x - y;
        }
        public double multiplication(double x, double y)
        {
            return x * y;
        }
        public double division(double x, double y)
        {
            return x / y;
        }
    }
}
