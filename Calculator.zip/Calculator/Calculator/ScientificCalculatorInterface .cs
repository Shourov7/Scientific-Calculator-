﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
   public interface ScientificCalculatorInterface
    {
        double XtoY(double x, double y);
        double fact(int y);
        void mod(double x, double y);
        void  DecimalToBinary(int x);

    }
}
